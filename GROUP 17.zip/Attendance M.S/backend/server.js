// server.js - The Complete and Corrected Backend Code

const express = require('express');
const cors = require('cors');
// This line assumes you have a 'db.js' file in the same directory
// that exports 'poolPromise' (your database connection pool) and 'sql' (the mssql library object).
const { poolPromise, sql } = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

// --- Middleware ---
app.use(cors()); // Enables Cross-Origin Resource Sharing for all routes
app.use(express.json()); // Parses incoming JSON requests

// --- Basic Route to confirm server is running ---
app.get('/', (req, res) => {
    res.send('🎉 Educational Portal API is working!');
});

// --- API Endpoints ---

// 1. Get all students
app.get('/api/students', async (req, res) => {
    try {
        const pool = await poolPromise;
        if (!pool) {
            return res.status(500).json({ success: false, message: 'DB not connected' });
        }
        const result = await pool.request().query('SELECT * FROM Students');
        res.json({ success: true, data: result.recordset });
    } catch (err) {
        console.error('Error fetching students:', err.message);
        res.status(500).json({ success: false, message: err.message });
    }
});

// 1a. Get specific student by ID (ADDED FOR STUDENT DASHBOARD)
app.get('/api/students/:id', async (req, res) => {
    try {
        const pool = await poolPromise;
        if (!pool) {
            return res.status(500).json({ success: false, message: 'DB not connected' });
        }
        const studentId = req.params.id;
        const result = await pool.request()
            .input('StudentID', sql.Int, studentId)
            .query('SELECT * FROM Students WHERE StudentID = @StudentID');
        
        if (result.recordset.length > 0) {
            res.json({ success: true, data: result.recordset[0] });
        } else {
            res.status(404).json({ success: false, message: 'Student not found' });
        }
    } catch (err) {
        console.error('Error fetching student:', err.message);
        res.status(500).json({ success: false, message: err.message });
    }
});

// 1b. Get student's enrolled courses (ADDED FOR STUDENT DASHBOARD)
app.get('/api/students/:id/courses', async (req, res) => {
    try {
        const pool = await poolPromise;
        if (!pool) {
            return res.status(500).json({ success: false, message: 'DB not connected' });
        }
        const studentId = req.params.id;
        const result = await pool.request()
            .input('StudentID', sql.Int, studentId)
            .query(`
                SELECT 
                    c.CourseID,
                    c.CourseName,
                    s.SubjectName,
                    r.RoomNumber,
                    t.Name AS TeacherName
                FROM CourseEnrollments ce
                JOIN Courses c ON ce.CourseID = c.CourseID
                JOIN Subjects s ON c.SubjectID = s.SubjectID
                LEFT JOIN Rooms r ON c.RoomID = r.RoomID
                LEFT JOIN Teachers t ON c.TeacherID = t.TeacherID
                WHERE ce.StudentID = @StudentID AND ce.Status = 'Active'
                ORDER BY c.CourseName
            `);
        res.json({ success: true, data: result.recordset });
    } catch (err) {
        console.error('Error fetching student courses:', err.message);
        res.status(500).json({ success: false, message: err.message });
    }
});

// 1c. Get student's today classes (ADDED FOR STUDENT DASHBOARD)
app.get('/api/students/:id/today-classes', async (req, res) => {
    try {
        const pool = await poolPromise;
        if (!pool) {
            return res.status(500).json({ success: false, message: 'DB not connected' });
        }
        const studentId = req.params.id;
        
        // Get the current day of the week
        const now = new Date();
        const today = now.toLocaleString('en-US', { weekday: 'long', timeZone: 'Asia/Karachi' });
        
        const result = await pool.request()
            .input('StudentID', sql.Int, studentId)
            .input('DayOfWeek', sql.NVarChar(20), today)
            .query(`
                SELECT
                    cs.DayOfWeek,
                    CONVERT(VARCHAR(5), cs.StartTime, 108) AS StartTime, 
                    CONVERT(VARCHAR(5), cs.EndTime, 108) AS EndTime,     
                    r.RoomNumber,
                    s.SubjectName,
                    c.CourseName,
                    t.Name AS TeacherName
                FROM ClassSchedule cs
                JOIN Courses c ON cs.CourseID = c.CourseID
                JOIN Subjects s ON c.SubjectID = s.SubjectID
                LEFT JOIN Rooms r ON c.RoomID = r.RoomID
                LEFT JOIN Teachers t ON c.TeacherID = t.TeacherID
                JOIN CourseEnrollments ce ON c.CourseID = ce.CourseID
                WHERE ce.StudentID = @StudentID
                    AND cs.DayOfWeek = @DayOfWeek
                    AND ce.Status = 'Active'
                ORDER BY cs.StartTime
            `);
        res.json({ success: true, data: result.recordset });
    } catch (err) {
        console.error('Error fetching today\'s classes:', err.message);
        res.status(500).json({ success: false, message: err.message });
    }
});

// 2. Get all teachers
app.get('/api/teachers', async (req, res) => {
    try {
        const pool = await poolPromise;
        if (!pool) {
            return res.status(500).json({ success: false, message: 'DB not connected' });
        }
        const result = await pool.request().query('SELECT * FROM Teachers');
        res.json({ success: true, data: result.recordset });
    } catch (err) {
        console.error('Error fetching teachers:', err.message);
        res.status(500).json({ success: false, message: err.message });
    }
});

// 3. Get all subjects
app.get('/api/subjects', async (req, res) => {
    try {
        const pool = await poolPromise;
        if (!pool) {
            return res.status(500).json({ success: false, message: 'DB not connected' });
        }
        const result = await pool.request().query('SELECT * FROM Subjects');
        res.json({ success: true, data: result.recordset });
    } catch (err) {
        console.error('Error fetching subjects:', err.message);
        res.status(500).json({ success: false, message: err.message });
    }
});

// 4. Get students by subject ID
app.get('/api/students/by-subject/:subjectId', async (req, res) => {
    try {
        const pool = await poolPromise;
        if (!pool) {
            return res.status(500).json({ success: false, message: 'DB not connected' });
        }
        const subjectId = req.params.subjectId;
        const result = await pool.request()
            .input('subjectId', sql.Int, subjectId)
            .query(`
                SELECT DISTINCT s.StudentID, s.Name, s.Email, s.RollNumber, s.Semester 
                FROM Students s
                JOIN CourseEnrollments ce ON s.StudentID = ce.StudentID
                JOIN Courses c ON ce.CourseID = c.CourseID
                WHERE c.SubjectID = @subjectId AND ce.Status = 'Active'
                ORDER BY s.Name;
            `);
        res.json({ success: true, data: result.recordset });
    } catch (err) {
        console.error('Error fetching students by subject:', err.message);
        res.status(500).json({ success: false, message: err.message });
    }
});

// 5. Submit attendance
app.post('/api/attendance', async (req, res) => {
    const { courseId, attendanceDate, attendanceRecords, markedByTeacherId } = req.body;
    if (!courseId || !attendanceDate || !attendanceRecords || !markedByTeacherId || !Array.isArray(attendanceRecords)) {
        return res.status(400).json({ success: false, message: 'Missing or invalid attendance data.' });
    }

    try {
        const pool = await poolPromise;
        if (!pool) {
            return res.status(500).json({ success: false, message: 'DB not connected' });
        }
        const transaction = new sql.Transaction(pool);
        await transaction.begin();

        try {
            await transaction.request()
                .input('courseId', sql.Int, courseId)
                .input('attendanceDate', sql.Date, attendanceDate)
                .query('DELETE FROM Attendance WHERE CourseID = @courseId AND AttendanceDate = @attendanceDate');

            for (const record of attendanceRecords) {
                const studentId = record.StudentID; 
                const status = record.Status;
                const remarks = record.Remarks || null; 
                await transaction.request()
                    .input('courseId', sql.Int, courseId)
                    .input('studentId', sql.Int, studentId)
                    .input('attendanceDate', sql.Date, attendanceDate)
                    .input('status', sql.NVarChar(20), status)
                    .input('remarks', sql.NVarChar(255), remarks)
                    .input('markedBy', sql.Int, markedByTeacherId)
                    .query(`
                        INSERT INTO Attendance (CourseID, StudentID, AttendanceDate, Status, Remarks, MarkedBy)
                        VALUES (@courseId, @studentId, @attendanceDate, @status, @remarks, @markedBy)
                    `);
            }
            await transaction.commit();
            res.json({ success: true, message: 'Attendance submitted successfully' });
        } catch (err) {
            await transaction.rollback();
            throw err; 
        }
    } catch (err) {
        console.error('Error submitting attendance:', err.message);
        res.status(500).json({ success: false, message: err.message });
    }
});

// 6. Get attendance history (Teacher specific)
app.get('/api/attendance-history/teacher/:teacherId', async (req, res) => {
    try {
        const pool = await poolPromise;
        if (!pool) {
            return res.status(500).json({ success: false, message: 'DB not connected' });
        }
        const teacherId = req.params.teacherId;
        const courseId = req.query.courseId; 
        const request = pool.request().input('TeacherID', sql.Int, teacherId);
        if (courseId) {
            request.input('CourseID', sql.Int, courseId);
        } else {
            request.input('CourseID', sql.Int, null);
        }
        const result = await request.execute('sp_GetAttendanceHistory'); // Assuming this SP exists
        res.json({ success: true, data: result.recordset });
    } catch (err) {
        console.error('Error fetching attendance history:', err.message);
        res.status(500).json({ success: false, message: err.message });
    }
});

// 7. Login route (uses sp_AuthenticateUser)
app.post('/api/login', async (req, res) => {
    const { username, password, role: requestedRole } = req.body; 
    if (!username || !password || !requestedRole) {
        return res.status(400).json({ success: false, message: 'Please provide username, password, and role.' });
    }

    try {
        const pool = await poolPromise;
        if (!pool) {
            return res.status(500).json({ success: false, message: 'DB not connected' });
        }
        const request = pool.request()
            .input('Username', sql.NVarChar(50), username)
            .input('Password', sql.NVarChar(255), password);
            
        const result = await request.execute('sp_AuthenticateUser'); // Assuming this SP exists

        if (result.recordset.length > 0) {
            const user = result.recordset[0]; 
            if (user.Role.toLowerCase() !== requestedRole.toLowerCase()) {
                return res.status(403).json({ 
                    success: false, 
                    message: `Access denied. You are registered as a ${user.Role}, not a ${requestedRole}.` 
                });
            }
            res.json({ success: true, message: 'Login successful', user: {
                id: user.RoleID, 
                name: user.Name,
                role: user.Role, 
                userId: user.UserID 
            }});
        } else {
            res.status(401).json({ success: false, message: 'Invalid username or password.' });
        }
    } catch (err) {
        console.error('Error during login:', err.message);
        res.status(500).json({ success: false, message: 'Internal server error. Please try again later.' });
    }
});

// 10. Get Class Schedule (for both teachers and students)
app.get('/api/schedule', async (req, res) => {
    try {
        const pool = await poolPromise;
        if (!pool) {
            return res.status(500).json({ success: false, message: 'DB not connected' });
        }
        const result = await pool.request().query(`
            SELECT 
                cs.DayOfWeek,
                CONVERT(VARCHAR(5), cs.StartTime, 108) AS StartTime, -- Formatted time
                CONVERT(VARCHAR(5), cs.EndTime, 108) AS EndTime,     -- Formatted time
                r.RoomNumber,
                s.SubjectName,
                c.CourseName,
                t.Name AS TeacherName 
            FROM ClassSchedule cs
            JOIN Courses c ON cs.CourseID = c.CourseID
            JOIN Subjects s ON c.SubjectID = s.SubjectID
            JOIN Rooms r ON c.RoomID = r.RoomID
            JOIN Teachers t ON c.TeacherID = t.TeacherID
            ORDER BY 
                CASE cs.DayOfWeek
                    WHEN 'Monday' THEN 1 WHEN 'Tuesday' THEN 2 WHEN 'Wednesday' THEN 3
                    WHEN 'Thursday' THEN 4 WHEN 'Friday' THEN 5 WHEN 'Saturday' THEN 6
                    WHEN 'Sunday' THEN 7
                END, cs.StartTime;
        `);
        res.json({ success: true, data: result.recordset });
    } catch (err) {
        console.error('Error fetching schedule:', err.message);
        res.status(500).json({ success: false, message: err.message });
    }
});

// 11. Get Student Attendance Summary (by course)
app.get('/api/attendance/student/:studentId/summary', async (req, res) => {
    try {
        const pool = await poolPromise;
        if (!pool) {
            return res.status(500).json({ success: false, message: 'DB not connected' });
        }
        const studentId = req.params.studentId;
        const result = await pool.request()
            .input('StudentID', sql.Int, studentId)
            .query(`
                SELECT 
                    c.CourseID,
                    c.CourseName,
                    s.SubjectName,
                    COUNT(CASE WHEN a.Status = 'Present' THEN 1 END) AS PresentClasses,
                    COUNT(CASE WHEN a.Status = 'Late' THEN 1 END) AS LateClasses,
                    COUNT(CASE WHEN a.Status = 'Absent' THEN 1 END) AS AbsentClasses,
                    COUNT(a.AttendanceID) AS TotalClasses,
                    CASE 
                        WHEN COUNT(a.AttendanceID) > 0 
                        THEN CAST((COUNT(CASE WHEN a.Status IN ('Present', 'Late') THEN 1 END) * 100.0 / COUNT(a.AttendanceID)) AS DECIMAL(5,2))
                        ELSE 0 
                    END AS AttendancePercentage
                FROM CourseEnrollments ce
                JOIN Courses c ON ce.CourseID = c.CourseID
                JOIN Subjects s ON c.SubjectID = s.SubjectID
                LEFT JOIN Attendance a ON c.CourseID = a.CourseID AND a.StudentID = @StudentID
                WHERE ce.StudentID = @StudentID AND ce.Status = 'Active'
                GROUP BY c.CourseID, c.CourseName, s.SubjectName
                ORDER BY c.CourseName
            `);
        
        let overallPresent = 0;
        let overallTotal = 0;
        result.recordset.forEach(record => {
            overallPresent += record.PresentClasses + record.LateClasses; 
            overallTotal += record.TotalClasses;
        });
        const overallPercentage = overallTotal > 0 ? ((overallPresent / overallTotal) * 100).toFixed(2) : "0.00"; 

        res.json({ 
            success: true, 
            attendancePercentage: overallPercentage,
            totalClasses: overallTotal,
            attendedClasses: overallPresent,
            details: result.recordset 
        });
    } catch (err) {
        console.error('Error fetching student attendance summary:', err.message);
        res.status(500).json({ success: false, message: err.message });
    }
});

// 12. Get Detailed Attendance for a specific course and date (for View Details button)
app.get('/api/attendance-details/:courseId/:date', async (req, res) => {
    try {
        const pool = await poolPromise;
        if (!pool) {
            return res.status(500).json({ success: false, message: 'DB not connected' });
        }
        const { courseId, date } = req.params;
        const result = await pool.request()
            .input('CourseID', sql.Int, courseId)
            .input('AttendanceDate', sql.Date, date)
            .query(`
                SELECT 
                    a.StudentID, 
                    s.Name AS StudentName, 
                    s.Email, 
                    a.Status, 
                    a.Remarks
                FROM Attendance a
                JOIN Students s ON a.StudentID = s.StudentID
                WHERE a.CourseID = @CourseID AND a.AttendanceDate = @AttendanceDate
                ORDER BY s.Name;
            `);
        res.json({ success: true, data: result.recordset });
    } catch (err) {
        console.error('Error fetching attendance details:', err.message);
        res.status(500).json({ success: false, message: err.message });
    }
});

// 13. Get Enrolled Courses Count for a specific student
app.get('/api/student-dashboard/:studentId/enrolled-courses', async (req, res) => {
    try {
        const pool = await poolPromise;
        if (!pool) {
            return res.status(500).json({ success: false, message: 'DB not connected' });
        }
        const studentId = req.params.studentId;
        const result = await pool.request()
            .input('StudentID', sql.Int, studentId)
            .query(`
                SELECT COUNT(ce.CourseID) AS TotalEnrolledCourses
                FROM CourseEnrollments ce
                WHERE ce.StudentID = @StudentID AND ce.Status = 'Active';
            `);
        res.json({ success: true, count: result.recordset[0]?.TotalEnrolledCourses || 0 });
    } catch (err) {
        console.error('Error fetching enrolled courses count:', err.message);
        res.status(500).json({ success: false, message: err.message, count: 0 });
    }
});

// 14. Get Today's Classes for a specific student
app.get('/api/student-dashboard/:studentId/today-classes', async (req, res) => {
    try {
        const pool = await poolPromise;
        if (!pool) {
            return res.status(500).json({ success: false, message: 'DB not connected' });
        }
        const studentId = req.params.studentId;
        // Get the current day of the week (e.g., "Wednesday") considering local timezone (Pakistan Time)
        const now = new Date();
        const today = now.toLocaleString('en-US', { weekday: 'long', timeZone: 'Asia/Karachi' }); 
        
        const result = await pool.request()
            .input('StudentID', sql.Int, studentId)
            .input('DayOfWeek', sql.NVarChar(20), today)
            .query(`
                SELECT
                    cs.DayOfWeek,
                    CONVERT(VARCHAR(5), cs.StartTime, 108) AS StartTime, 
                    CONVERT(VARCHAR(5), cs.EndTime, 108) AS EndTime,     
                    r.RoomNumber,
                    s.SubjectName,
                    c.CourseName,
                    t.Name AS TeacherName
                FROM ClassSchedule cs
                JOIN Courses c ON cs.CourseID = c.CourseID
                JOIN Subjects s ON c.SubjectID = s.SubjectID
                JOIN Rooms r ON c.RoomID = r.RoomID
                JOIN Teachers t ON c.TeacherID = t.TeacherID
                JOIN CourseEnrollments ce ON c.CourseID = ce.CourseID
                WHERE ce.StudentID = @StudentID
                    AND cs.DayOfWeek = @DayOfWeek
                    AND ce.Status = 'Active'
                ORDER BY cs.StartTime;
            `);
        res.json({ success: true, classes: result.recordset, count: result.recordset.length });
    } catch (err) {
        console.error('Error fetching today\'s classes:', err.message);
        res.status(500).json({ success: false, message: err.message, classes: [], count: 0 });
    }
});

// 15. Get Student Dashboard Data (Main endpoint to fetch all profile, attendance summary, counts)
app.get('/api/student-dashboard/:studentId', async (req, res) => {
    const { studentId } = req.params;
    try {
        const pool = await poolPromise;
        if (!pool) {
            return res.status(500).json({ success: false, message: 'DB not connected' });
        }

        // --- 1. Fetch Overall Attendance Percentage ---
        const attendanceSummaryResult = await pool.request()
            .input('StudentID', sql.Int, studentId)
            .query(`
                SELECT 
                    COUNT(CASE WHEN a.Status IN ('Present', 'Late') THEN 1 END) AS AttendedClasses,
                    COUNT(a.AttendanceID) AS TotalClasses
                FROM CourseEnrollments ce
                JOIN Courses c ON ce.CourseID = c.CourseID
                LEFT JOIN Attendance a ON c.CourseID = a.CourseID AND a.StudentID = @StudentID
                WHERE ce.StudentID = @StudentID AND ce.Status = 'Active';
            `);

        let attendancePercentage = "0.00";
        const totalAttended = attendanceSummaryResult.recordset[0]?.AttendedClasses || 0;
        const totalPossible = attendanceSummaryResult.recordset[0]?.TotalClasses || 0;

        if (totalPossible > 0) {
            attendancePercentage = ((totalAttended / totalPossible) * 100).toFixed(2);
        }

        // --- 2. Fetch Student Profile Details ---
        const studentDetailsResult = await pool.request()
            .input('StudentID', sql.Int, studentId) 
            .query('SELECT StudentID, Name, RollNumber, Email, Semester, Department FROM Students WHERE StudentID = @StudentID');

        const studentData = studentDetailsResult.recordset[0];

        // --- 3. Fetch Enrolled Courses Count ---
        const enrolledCoursesResult = await pool.request()
            .input('StudentID', sql.Int, studentId)
            .query(`
                SELECT COUNT(ce.CourseID) AS TotalEnrolledCourses
                FROM CourseEnrollments ce
                WHERE ce.StudentID = @StudentID AND ce.Status = 'Active';
            `);
        const totalEnrolledCourses = enrolledCoursesResult.recordset[0]?.TotalEnrolledCourses || 0;

        // --- 4. Fetch Today's Classes Count ---
        const now = new Date();
        const today = now.toLocaleString('en-US', { weekday: 'long', timeZone: 'Asia/Karachi' }); 

        const todayClassesResult = await pool.request()
            .input('StudentID', sql.Int, studentId)
            .input('DayOfWeek', sql.NVarChar(20), today)
            .query(`
                SELECT COUNT(cs.ScheduleID) AS ClassesTodayCount
                FROM ClassSchedule cs
                JOIN Courses c ON cs.CourseID = c.CourseID
                JOIN CourseEnrollments ce ON c.CourseID = ce.CourseID
                WHERE ce.StudentID = @StudentID
                    AND cs.DayOfWeek = @DayOfWeek
                    AND ce.Status = 'Active';
            `);
        const classesTodayCount = todayClassesResult.recordset[0]?.ClassesTodayCount || 0;


        // --- Respond with all fetched data ---
        if (studentData) {
            res.json({
                success: true,
                student: {
                    id: studentData.StudentID,
                    name: studentData.Name,
                    rollNumber: studentData.RollNumber,
                    email: studentData.Email,
                    semester: studentData.Semester,
                    department: studentData.Department, // Ensure this column exists in your Students table
                    attendancePercentage: attendancePercentage,
                    totalEnrolledCourses: totalEnrolledCourses,
                    classesToday: classesTodayCount
                }
            });
        } else {
            res.status(404).json({ success: false, message: 'Student not found or no active enrollments.', student: {
                id: studentId, // Still return the requested ID
                name: 'N/A',
                rollNumber: 'N/A',
                email: 'N/A',
                semester: 'N/A',
                department: 'N/A',
                attendancePercentage: "0.00",
                totalEnrolledCourses: 0,
                classesToday: 0
            }});
        }

    } catch (err) {
        console.error('Error fetching student dashboard data:', err.message);
        res.status(500).json({ success: false, message: err.message, student: null });
    }
});


// --- Debugging Endpoints ---

// Test student data, enrollments, attendance records
app.get('/api/test-student/:studentId', async (req, res) => {
    try {
        const pool = await poolPromise;
        const studentId = req.params.studentId;
        
        const studentCheck = await pool.request()
            .input('StudentID', sql.Int, studentId)
            .query('SELECT * FROM Students WHERE StudentID = @StudentID');
            
        const enrollmentCheck = await pool.request()
            .input('StudentID', sql.Int, studentId)
            .query('SELECT ce.*, c.CourseName, s.SubjectName FROM CourseEnrollments ce JOIN Courses c ON ce.CourseID = c.CourseID JOIN Subjects s ON c.SubjectID = s.SubjectID WHERE ce.StudentID = @StudentID');
            
        const attendanceCheck = await pool.request()
            .input('StudentID', sql.Int, studentId)
            .query('SELECT a.*, c.CourseName FROM Attendance a JOIN Courses c ON a.CourseID = c.CourseID WHERE a.StudentID = @StudentID');
            
        res.json({
            success: true,
            studentExists: studentCheck.recordset.length > 0,
            enrollments: enrollmentCheck.recordset.length,
            attendanceRecords: attendanceCheck.recordset.length,
            studentData: studentCheck.recordset[0] || null,
            enrollmentData: enrollmentCheck.recordset,
            attendanceData: attendanceCheck.recordset
        });
    } catch (err) {
        console.error('Error in /api/test-student:', err.message);
        res.status(500).json({ success: false, error: err.message });
    }
});

// Test database connection and show table counts
app.get('/api/test-db', async (req, res) => {
    try {
        const pool = await poolPromise;
        if (!pool) {
            return res.status(500).json({ success: false, message: 'DB not connected' });
        }

        const tests = {};
        const tables = ['Users', 'Teachers', 'Students', 'Subjects', 'Rooms', 'Courses', 'CourseEnrollments', 'ClassSchedule', 'Attendance', 'Notifications'];

        for (const table of tables) {
            try {
                const countResult = await pool.request().query(`SELECT COUNT(*) as count FROM ${table}`);
                tests[table] = countResult.recordset[0].count;
            } catch (err) {
                tests[table] = `Table not found or error: ${err.message}`;
            }
        }

        res.json({ success: true, tests });
    } catch (err) {
        console.error('Error during database test:', err.message);
        res.status(500).json({ success: false, message: err.message });
    }
});

// --- Server Start ---
app.listen(PORT, () => {
    console.log(`🚀 Backend running on http://localhost:${PORT}`);
    console.log(`--- Test Endpoints ---`);
    console.log(`📊 Database connection/table count: http://localhost:${PORT}/api/test-db`);
    console.log(`👤 Specific student data test: http://localhost:${PORT}/api/test-student/:studentId`);
    console.log(`--- API Endpoints ---`);
    console.log(`👥 Get all students: http://localhost:${PORT}/api/students`);
    console.log(`👨‍🏫 Get all teachers: http://localhost:${PORT}/api/teachers`);
    console.log(`📚 Get all subjects: http://localhost:${PORT}/api/subjects`);
    console.log(`🗓️ Get all schedules: http://localhost:${PORT}/api/schedule`);
    console.log(`Login route (POST): /api/login`);
    console.log(`Login route (POST): /api/login`);
    console.log(`Submit attendance (POST): /api/attendance`);
    console.log(`Teacher attendance history (GET): /api/attendance-history/teacher/:teacherId`);
    console.log(`Student attendance summary (GET): /api/attendance/student/:studentId/summary`);
    console.log(`Detailed attendance (GET): /api/attendance-details/:courseId/:date`);
    console.log(`Student dashboard (GET, main endpoint): /api/student-dashboard/:studentId`);
    console.log(`Student enrolled courses count (GET): /api/student-dashboard/:studentId/enrolled-courses`);
    console.log(`Student today's classes (GET): /api/student-dashboard/:studentId/today-classes`);
});